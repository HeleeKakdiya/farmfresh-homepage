<?php include 'header.php'; ?>

<div class="welcome-section">
    <div class="container text-center">
        <h1>Welcome to FarmFresh</h1>
        <p>We’re farmers, purveyors, and eaters of organically grown food.</p>
        <a href="#" class="btn btn-shop">Browse Our Shop</a>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-4">
            <img src="images/left-image.jpg" alt="Left Image" class="img-fluid left-image">
            <div class="mt-4">
                <img src="images/5.jpg" alt="Left Image" class="img-fluid left-image">
            </div>
        </div>
        <div class="col-md-8">
            <div class="row">
                <div class="col-md-6">
                    <img src="images/middle-image.jpg" alt="Middle Image" class="img-fluid">
                </div>
                <div class="col-md-6">
                    <img src="images/right-image.jpg" alt="Right Image" class="img-fluid thicker">
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <img src="images/4.jpg" alt="Full Width Image" class="img-fluid full-width">
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-md-12">
                    <p class="text-below">At FarmFresh, we aim to provide the freshest and highest quality products directly from local farmers to your doorstep. We are committed to supporting sustainable agriculture and fostering community engagement.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-5">
            <h1 class="title" style="font-size: 40px;">Mission We Are Working On</h1>
            <p class="text">We offer a wide variety of organic and locally sourced products, ensuring that you and your family enjoy healthy and nutritious meals.</p>
            <p class="text">In addition to our commitment to providing fresh produce, we also prioritize sustainability in every aspect of our operations. From reducing food waste to promoting eco-friendly packaging, we strive to minimize our environmental impact while delivering exceptional products to our customers.</p>
            <p class="text">At FarmFresh, we believe in the power of community. That's why we're dedicated to fostering connections between consumers and local farmers. By supporting us, you're not just getting fresh, high-quality produce – you're also contributing to the growth and sustainability of local agriculture.</p>    
            <p class="text">Our team at FarmFresh is constantly exploring new ways to innovate and improve. Whether it's implementing cutting-edge technology or refining our processes, we're committed to delivering the best possible experience to our customers.</p>
        </div>
        <div class="col-md-7 mt-7">
            <img src="images/2.3.jpg" alt="Full Width Image" class="img-fluid" style="width: 100%; height: auto;">
            <div class="row mt-12">
                <div class="row mt-4">
                    <div class="col-md-6">
                        <img src="images/2.2.jpg" alt="Half Width Image 2" class="img-fluid" style="width: 100%; height: auto;">
                    </div>
                    <div class="col-md-6">
                        <img src="images/2.1.jpg" alt="Half Width Image 3" class="img-fluid" style="width: 100%; height: auto;">
                    </div>
                </div>
                <div class="col-md-5">
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid" style="background-color: #FAFAF5; padding: 10px;">
    <div class="container mt-5">
        <h2 class="text-center mb-4" style="color: #426B1F; font-size: 40px;">Choose From The Best</h2>
        <div class="row justify-content-center">
            <div class="col-md-2 mb-4">
                <img src="images/1farmer.jpg" alt="Farmer 1" class="img-fluid mb-3" style="max-width: 100%;">
                <p style="font-size: 20px; color: #333; text-align: center;">John Doe</p>
            </div>
            <div class="col-md-2 mb-4">
                <img src="images/2farmer.jpg" alt="Farmer 2" class="img-fluid mb-3" style="max-width: 100%;">
                <p style="font-size: 20px; color: #333; text-align: center;">Jane Smith</p>
            </div>
            <div class="col-md-2 mb-4">
                <img src="images/3farmer.jpg" alt="Farmer 3" class="img-fluid mb-3" style="max-width: 100%;">
                <p style="font-size: 20px; color: #333; text-align: center;">Mike Johnson</p>
            </div>
            <div class="col-md-2 mb-4">
                <img src="images/4farmer.jpg" alt="Farmer 4" class="img-fluid mb-3" style="max-width: 100%;">
                <p style="font-size: 20px; color: #333; text-align: center;">Emily Brown</p>
            </div>
            <div class="col-md-2 mb-4">
                <img src="images/5farmer.jpg" alt="Farmer 5" class="img-fluid mb-3" style="max-width: 100%;">
                <p style="font-size: 20px; color: #333; text-align: center;">David Lee</p>
            </div>
            <div class="col-md-2 mb-4">
                <img src="images/6farmer.jpg" alt="Farmer 6" class="img-fluid mb-3" style="max-width: 100%;">
                <p style="font-size: 20px; color: #333; text-align: center;">Taylor Swift</p>
            </div>
        </div>
    </div>
</div>

<div class="container mt-5"></div>

<div class="container-fluid" style="padding: 20px;">
    <div class="container text-center">
        <h2 style="color: #426B1F; font-size: 40px;">Discover The Taste With Promotional Offers</h2>
    </div>
</div>

<div class="container mt-7">
    <div class="row justify-content-center">
        <?php
        // Connection MySQL database
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "farmfresh";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch promotional offers data from the database
        $sql = "SELECT * FROM promotions";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row
            while ($row = $result->fetch_assoc()) {
                echo '<div class="col-md-4 mb-4">';
                echo '<div class="card promotion-card" style="height: 400px;">';
                echo '<img src="' . $row['image_url'] . '" class="card-img-top" alt="' . $row['title'] . '" style="height: 230px;">';
                echo '<div class="card-body" style="height: 150px;">';
                echo '<h5 class="card-title">' . $row['title'] . '</h5>';
                echo '<p class="card-text">' . $row['description'] . '</p>';
                echo '<p class="card-text">Discount: ' . $row['discount_percentage'] . '%</p>';
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "0 results";
        }
        $conn->close();
        ?>
    </div>
</div>

<?php include 'footer.php'; ?>

<style>
.promotion-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.promotion-card:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.text-below {
    text-align: center;
}

.title {
    text-align: center;
}

/* Adjustments for mobile responsiveness */
@media (max-width: 768px) {
    .left-image, .thicker, .full-width {
        width: 100%;
        height: auto;
    }

    .container, .container-fluid {
        padding: 15px;
    }

    .promotion-card {
        height: auto;
    }

    /* Hide footer sections except Contact Us and social media icons */
    .footer .col-md-3:not(:last-child) {
        display: none;
    }

    .footer .col-md-3:last-child {
        text-align: center;
    }
}
</style>
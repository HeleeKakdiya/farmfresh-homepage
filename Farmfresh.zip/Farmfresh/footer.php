<div class="container-fluid footer mt-5 py-4" style="background-color: #1B4821; color:white;">
    <div class="container">
        <div class="row" style="padding:15px;">
            <div class="col-md-3">
                <img src="images/logo.jpg" alt="FarmFresh Logo" class="img-fluid mb-3">
            </div>
            <div class="col-md-3">
                <h5 class="mb-3">Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About</a></li>
                    <li><a href="#">Contact</a></li>
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">My Profile</a></li>
                    <li><a href="#">Blog</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5 class="mb-3">Products</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Vegetables</a></li>
                    <li><a href="#">Fruits</a></li>
                    <li><a href="#">Dairy</a></li>
                    <li><a href="#">Flowers</a></li>
                    <li><a href="#">Herbs</a></li>
                    <li><a href="#">Others</a></li>
                </ul>
            </div>
            <div class="col-md-3">
                <h5 class="mb-3">Contact Us</h5>
                <p><strong>Business inquiry:</strong><br>123-456-7890</p>
                <p><strong>Customer care:</strong><br>123-456-7490</p>
                <div class="mt-3">
                    <a href="index.php"><i class="fab fa-facebook fa-2x" style="color: white; padding:1px;"></i></a>
                    <a href="index.php"><i class="fab fa-twitter fa-2x" style="color: white; padding:1px;"></i></a>
                    <a href="index.php"><i class="fab fa-instagram fa-2x" style="color: white; padding:1px;"></i></a>
                    <a href="index.php"><i class="fab fa-linkedin fa-2x" style="color: white; padding:1px;"></i></a>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <hr style="border-top: 1px solid white;">
        <div class="text-center mt-3 mb-3">
            <p>© 2023 FarmFresh | All Rights Reserved</p>
        </div>
    </div>   
</div>
